cout << Matrix<double, 3, 4>::Identity() << endl;
